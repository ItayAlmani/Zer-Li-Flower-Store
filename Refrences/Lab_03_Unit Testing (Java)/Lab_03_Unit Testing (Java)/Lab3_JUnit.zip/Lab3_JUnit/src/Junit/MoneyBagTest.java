package Junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import methods.Money;
import methods.MoneyBag;

public class MoneyBagTest {
	
	private Money m12chf;
	private Money m14usd;
	private Money m16ils;
	private MoneyBag mb;
	
	@Before
	public void setUp() throws Exception {
		m12chf= new Money(12,"CHF");
		m14usd= new Money(14,"USD");
		m16ils = new Money(16,"ILS");
		mb = new MoneyBag(m12chf, m14usd);
	}

	@Test
	public void testAddMoney() {
		MoneyBag expected1 = new MoneyBag(new Money[] {m12chf,m14usd,m16ils});
		MoneyBag result1 = (MoneyBag) mb.addMoney(m16ils);
		assertEquals(expected1, result1);
		
		MoneyBag expected2 = new MoneyBag(new Money[] {m12chf,m14usd});
		assertNotEquals(expected2, result1);
		
		MoneyBag result2 = (MoneyBag) mb.addMoney(m16ils);
		assertEquals(expected1,result2);
		
		/*Add null test*/
		//MoneyBag result3 = (MoneyBag) mb.addMoney(null);
		//assertNotEquals(expected1,result3);
	}
	
	@Test
	public void testContains() {
		assertTrue(mb.contains(m12chf));
		assertTrue(mb.contains(m14usd));
		assertFalse(mb.contains(m16ils));
		/*Add null test*/
		//assertFalse(mb.contains(null));
	}

}
